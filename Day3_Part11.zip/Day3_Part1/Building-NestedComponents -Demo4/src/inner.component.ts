import { Component,Output,EventEmitter } from '@angular/core';
import { ParentComponent } from './outer.component';

@Component({
  selector: 'child-selector',
  template: ` <h2>Hi, I'm a nested component</h2>  
		  <span (click)='namer()'>Get my name!</span>
		  <span (click)='doer()'>Get my Job!</span>
		  `
})

export class ChildComponent {  
  @Output() nameFetch: EventEmitter<string> = new EventEmitter<string>();
  @Output() workFetch: EventEmitter<string> = new EventEmitter<string>();

  namer() {
    this.nameFetch.emit("My name is Khan");
  }
  doer() {
    this.workFetch.emit("My Job is to sleeeeeep");
  }
}
