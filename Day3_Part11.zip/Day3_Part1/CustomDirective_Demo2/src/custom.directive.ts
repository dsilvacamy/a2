import { Directive,Inject,ElementRef } from '@angular/core';
@Directive({ 
   selector: '[testRed]'
})
export class RedDirective {
    constructor(@Inject(ElementRef) el:ElementRef) {
        el.nativeElement.style.color = 'red';
    }
}
