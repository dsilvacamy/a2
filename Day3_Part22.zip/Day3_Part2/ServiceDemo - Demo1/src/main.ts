import { Component,Inject,OnInit,NgModule,enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { ExampleService } from './demo1.service'


enableProdMode();

@Component({
    selector: 'my-app',
    template: '<h1>{{ title }}</h1>',
    providers: [ExampleService]
})

export class Demo1Component implements OnInit{
    title:string;
   constructor(@Inject(ExampleService) private _exampleService: ExampleService) {
	}
	ngOnInit() {
        this.title = this._exampleService.someMethod();
   }
  
}

@NgModule({
  imports:[ BrowserModule ],
  declarations:[ Demo1Component ],
  providers:[ExampleService],
  bootstrap:[ Demo1Component ]
})
class AppModule{}

platformBrowserDynamic().bootstrapModule(AppModule);