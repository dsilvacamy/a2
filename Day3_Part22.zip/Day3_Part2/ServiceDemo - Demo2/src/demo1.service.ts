import { Injectable } from '@angular/core';

@Injectable()
export class ExampleService {

    addMethod(num1:Number,num2:Number) {
        return parseInt(num1)+parseInt(num2);
    }
	subtractMethod(num1:Number,num2:Number){
	 return num1-num2;
	}

}