import { Component, NgModule, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms'
import { Employee } from './Employee'
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
enableProdMode();

@Component({
  selector: 'my-app',
  templateUrl: 'src/employee.component.html'
})

export class EmpComponent {
onSubmit(emp:Employee,isValid:boolean){
    if(isValid)
   	  alert("Name : "+emp.name+" Age : "+emp.desig);
	}
}


  