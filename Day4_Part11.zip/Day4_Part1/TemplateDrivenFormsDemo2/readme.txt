We'll build this form in small steps:

1) Create the Hero model class.
2) Create the component that controls the form.
3) Create a template with the initial form layout.
4) Bind data properties to each form control using the ngModel two-way data binding syntax.
5) Add a name attribute to each form input control.
6) Add custom CSS to provide visual feedback.
7) Show and hide validation error messages.
8) Handle form submission with ngSubmit.
9) Disable the form�s submit button until the form is valid.

hero-form.component.ts



1) The code imports the Angular core library, and the Hero model we just created.
2) The @Component selector value of "hero-form" means we can drop this form in a parent template with a <hero-form> tag.
3) The moduleId: module.id property sets the base for module-relative loading of the templateUrl.
4) The templateUrl property points to a separate file for the template HTML.
5) We defined dummy data for model and powers, as befits a demo. Down the road, we can inject a data service to get and save real data or perhaps expose these properties as inputs and outputs for binding to a parent component. None of this concerns us now and these future changes won't affect our form.
6) We threw in a diagnostic property to return a JSON representation of our model. It'll help us see what we're doing during our development; we've left ourselves a cleanup note to discard it later.


Why the separate template file?
Why don't we write the template inline in the component file as we often do elsewhere?

There is no �right� answer for all occasions. We like inline templates when they are short. Most form templates won't be short. TypeScript and JavaScript files generally aren't the best place to write (or read) large stretches of HTML and few editors are much help with files that have a mix of HTML and code. We also like short files with a clear and obvious purpose like this one.

Form templates tend to be quite large even when displaying a small number of fields so it's usually best to put the HTML template in a separate file. We'll write that template file in a moment. Before we do, we'll take a step back and revise the app.module.ts and app.component.ts to make use of the new HeroFormComponent.